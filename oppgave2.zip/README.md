Look inside index.js
Use modern js where possible (see comments)
