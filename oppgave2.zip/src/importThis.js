// export this value
// documentation: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/export
const initialList = [1, 2, 3, 4, 5, 6];

export default initialList;
