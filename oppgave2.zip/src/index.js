import "./styles.scss";
import initialList from "./importThis.js";

const buttons = [
  { id: "prev", value: "prev" },
  { id: "next", value: "next" }
];

const listWrapper = document.querySelector("#traverse");
const buttonWrapper = document.querySelector("#buttonWrapper");

const addListItems = () => {
  initialList.map(
    (item) =>
      (listWrapper.innerHTML +=
        item === 1
          ? `<li class="active" data-key=${item}>${item}</li>`
          : `<li data-key=${item}>${item}</li>`)
  );
};

const addButtons = () => {
  buttons.map((obj) => {
    const { id, value } = obj;
    buttonWrapper.innerHTML += `<button type='button' id=${id}>${value}</button>`;
    return obj;
  });
};

const setClass = (prevActive, nextActive) => {
  prevActive.classList.remove("active");
  const listItems = [...document.querySelectorAll("[data-key]")];
  const next = listItems.find(
    (element) => Number(element.dataset.key) === nextActive
  );
  if (next) {
    next.classList.add("active");
  }
};

const getCurrentActive = () => {
  return document.querySelector(".active");
};

const setNextActive = () => {
  const currentActive = getCurrentActive();
  const nextActive = Number(currentActive?.dataset?.key) + 1;
  const active = nextActive > initialList.length ? 1 : nextActive;
  setClass(currentActive, active);
};

const setPrevActive = () => {
  const currentActive = getCurrentActive();
  const prevActive = Number(currentActive?.dataset?.key) - 1;
  const active = prevActive < 1 ? initialList.length : prevActive;
  setClass(currentActive, active);
};

const traverse = (event) => {
  const { target } = event;
  const targetId = target?.id;
  switch (targetId) {
    case "next":
      setNextActive();
      break;
    case "prev":
      setPrevActive();
      break;
    default:
      break;
  }
};

const addClickEvents = (handler = traverse) => {
  const btns = document.querySelectorAll("button");
  const btnArray = [...btns];
  for (const button of btnArray) {
    button.addEventListener("click", handler);
  }
};

addListItems();
addButtons();
addClickEvents();
